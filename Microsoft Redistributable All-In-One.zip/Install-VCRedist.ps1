<#
===============================================================================
  Visual C++ Redistributable All-in-One Installer
-------------------------------------------------------------------------------
  Created by : Kaelen & Claude (Anthropic)
  Date       : 2026-10-04
  Source     : https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist

  Downloads every x86 and x64 Visual C++ Redistributable from Microsoft's
  official servers, checks that each file has a valid Microsoft digital
  signature, installs it silently, then deletes all downloads.

  Installs: 2005 SP1, 2008 SP1, 2010 SP1, 2012 Update 4, 2013, and the
            latest v14 (2017-2026). The v14 package also covers Visual C++
            2015, since 2015-2026 share the same runtime.

  Usage   : Double-click Install-VCRedist.bat (it asks for Administrator
            rights automatically).
===============================================================================
#>
#Requires -Version 5.1
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'   # Invoke-WebRequest is much faster without the progress bar

# Windows PowerShell 5.1 can default to old TLS versions; Microsoft's servers need TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

# -----------------------------------------------------------------------------
# Packages - all URLs are taken from the Microsoft Learn page above
# (2005 SP1 comes from Microsoft download id=26347, which that page links to)
# -----------------------------------------------------------------------------
$packages = @(
    @{ Name = 'Visual C++ 2005 SP1';        Arch = 'x86'; Version = '8.0.61001';      Args = '/q'
       Url  = 'https://download.microsoft.com/download/8/B/4/8B42259F-5D70-43F4-AC2E-4B208FD8D66A/vcredist_x86.EXE' }
    @{ Name = 'Visual C++ 2005 SP1';        Arch = 'x64'; Version = '8.0.61001';      Args = '/q'
       Url  = 'https://download.microsoft.com/download/8/B/4/8B42259F-5D70-43F4-AC2E-4B208FD8D66A/vcredist_x64.EXE' }

    @{ Name = 'Visual C++ 2008 SP1';        Arch = 'x86'; Version = '9.0.30729.5677'; Args = '/q'
       Url  = 'https://download.microsoft.com/download/5/D/8/5D8C65CB-C849-4025-8E95-C3966CAFD8AE/vcredist_x86.exe' }
    @{ Name = 'Visual C++ 2008 SP1';        Arch = 'x64'; Version = '9.0.30729.5677'; Args = '/q'
       Url  = 'https://download.microsoft.com/download/5/D/8/5D8C65CB-C849-4025-8E95-C3966CAFD8AE/vcredist_x64.exe' }

    @{ Name = 'Visual C++ 2010 SP1';        Arch = 'x86'; Version = '10.0.40219.325'; Args = '/q /norestart'
       Url  = 'https://download.microsoft.com/download/1/6/5/165255E7-1014-4D0A-B094-B6A430A6BFFC/vcredist_x86.exe' }
    @{ Name = 'Visual C++ 2010 SP1';        Arch = 'x64'; Version = '10.0.40219.325'; Args = '/q /norestart'
       Url  = 'https://download.microsoft.com/download/1/6/5/165255E7-1014-4D0A-B094-B6A430A6BFFC/vcredist_x64.exe' }

    @{ Name = 'Visual C++ 2012 Update 4';   Arch = 'x86'; Version = '11.0.61030.0';   Args = '/install /quiet /norestart'
       Url  = 'https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x86.exe' }
    @{ Name = 'Visual C++ 2012 Update 4';   Arch = 'x64'; Version = '11.0.61030.0';   Args = '/install /quiet /norestart'
       Url  = 'https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x64.exe' }

    @{ Name = 'Visual C++ 2013';            Arch = 'x86'; Version = '12.0.40664.0';   Args = '/install /quiet /norestart'
       Url  = 'https://aka.ms/highdpimfc2013x86enu' }
    @{ Name = 'Visual C++ 2013';            Arch = 'x64'; Version = '12.0.40664.0';   Args = '/install /quiet /norestart'
       Url  = 'https://aka.ms/highdpimfc2013x64enu' }

    @{ Name = 'Visual C++ 2017-2026 (v14)'; Arch = 'x86'; Version = 'latest';         Args = '/install /quiet /norestart'
       Url  = 'https://aka.ms/vc14/vc_redist.x86.exe' }
    @{ Name = 'Visual C++ 2017-2026 (v14)'; Arch = 'x64'; Version = 'latest';         Args = '/install /quiet /norestart'
       Url  = 'https://aka.ms/vc14/vc_redist.x64.exe' }
)

# Installer exit codes that count as success
$okExitCodes = @{
    0    = 'Installed'
    3010 = 'Installed (restart required)'
    1641 = 'Installed (restart required)'
    1638 = 'Already installed (same or newer version)'
    5100 = 'Already installed (newer version)'
}

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
function Save-Installer {
    param([string]$Url, [string]$Destination)

    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing
            return
        }
        catch {
            if ($attempt -eq 3) { throw "Download failed: $($_.Exception.Message)" }
            Write-Host "    Download failed (attempt $attempt of 3), retrying..." -ForegroundColor DarkYellow
            Start-Sleep -Seconds 3
        }
    }
}

function Test-MicrosoftSignature {
    param([string]$Path)

    $sig = Get-AuthenticodeSignature -FilePath $Path
    return ($sig.Status -eq 'Valid' -and $sig.SignerCertificate.Subject -match 'O=Microsoft Corporation')
}

# -----------------------------------------------------------------------------
# Start
# -----------------------------------------------------------------------------
Write-Host ''
Write-Host '=====================================================' -ForegroundColor Cyan
Write-Host '   Visual C++ Redistributable All-in-One Installer'    -ForegroundColor Cyan
Write-Host '   Created by Kaelen & Claude (Anthropic)'             -ForegroundColor DarkCyan
Write-Host '=====================================================' -ForegroundColor Cyan

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host ''
    Write-Host 'This script must be run as Administrator. Please use Install-VCRedist.bat.' -ForegroundColor Red
    exit 1
}

$is64BitOS     = [Environment]::Is64BitOperatingSystem
$workDir       = Join-Path $env:TEMP ('VCRedist_' + [guid]::NewGuid().ToString('N').Substring(0, 8))
$results       = New-Object System.Collections.Generic.List[object]
$restartNeeded = $false

try {
    New-Item -ItemType Directory -Path $workDir -Force | Out-Null

    $index = 0
    foreach ($pkg in $packages) {
        $index++
        $label = "$($pkg.Name) $($pkg.Arch)"

        Write-Host ''
        Write-Host "[$index/$($packages.Count)] $label" -ForegroundColor Cyan

        if ($pkg.Arch -eq 'x64' -and -not $is64BitOS) {
            Write-Host '    Skipped: x64 packages cannot be installed on 32-bit Windows.' -ForegroundColor DarkGray
            $results.Add([pscustomobject]@{ Package = $label; Result = 'Skipped (32-bit Windows)'; Ok = $true })
            continue
        }

        try {
            $file = Join-Path $workDir (($pkg.Name -replace '[^A-Za-z0-9]+', '_').Trim('_') + "_$($pkg.Arch).exe")

            Write-Host '    Downloading...'
            Save-Installer -Url $pkg.Url -Destination $file

            if (-not (Test-MicrosoftSignature -Path $file)) {
                throw 'File does not have a valid Microsoft signature; it was not installed.'
            }

            $version = $pkg.Version
            if ($version -eq 'latest') { $version = (Get-Item -LiteralPath $file).VersionInfo.ProductVersion }
            $sizeMB = [math]::Round((Get-Item -LiteralPath $file).Length / 1MB, 1)
            Write-Host "    Downloaded $sizeMB MB - Microsoft signature verified - version $version"

            Write-Host '    Installing...'
            $proc = Start-Process -FilePath $file -ArgumentList $pkg.Args -Wait -PassThru
            $code = $proc.ExitCode

            if ($okExitCodes.ContainsKey($code)) {
                if ($code -eq 3010 -or $code -eq 1641) { $restartNeeded = $true }
                Write-Host "    $($okExitCodes[$code])" -ForegroundColor Green
                $results.Add([pscustomobject]@{ Package = $label; Result = $okExitCodes[$code]; Ok = $true })
            }
            else {
                throw "Installer exited with code $code."
            }
        }
        catch {
            Write-Host "    FAILED: $($_.Exception.Message)" -ForegroundColor Red
            $results.Add([pscustomobject]@{ Package = $label; Result = "FAILED - $($_.Exception.Message)"; Ok = $false })
        }
    }
}
finally {
    # Runs even if the script errors out or is cancelled with Ctrl+C
    Write-Host ''
    Write-Host 'Cleaning up downloaded files...' -ForegroundColor Cyan
    for ($n = 1; $n -le 5 -and (Test-Path -LiteralPath $workDir); $n++) {
        Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path -LiteralPath $workDir) { Start-Sleep -Seconds 2 }
    }
    if (Test-Path -LiteralPath $workDir) {
        Write-Host "    Could not fully remove $workDir - you can delete it manually." -ForegroundColor Yellow
    }
    else {
        Write-Host '    All downloads deleted.' -ForegroundColor Green
    }
}

# -----------------------------------------------------------------------------
# Summary
# -----------------------------------------------------------------------------
Write-Host ''
Write-Host '======================== Summary ========================' -ForegroundColor Cyan
foreach ($r in $results) {
    $color = if ($r.Ok) { 'Green' } else { 'Red' }
    Write-Host ('  {0,-32} {1}' -f $r.Package, $r.Result) -ForegroundColor $color
}
Write-Host '=========================================================' -ForegroundColor Cyan

$failed = @($results | Where-Object { -not $_.Ok }).Count
if ($failed -gt 0) {
    Write-Host "$failed package(s) failed to install." -ForegroundColor Red
}
else {
    Write-Host 'All Visual C++ Redistributables are installed.' -ForegroundColor Green
}
if ($restartNeeded) {
    Write-Host 'A restart is required to finish the installation.' -ForegroundColor Yellow
}

if ($failed -gt 0) { exit 1 } else { exit 0 }
