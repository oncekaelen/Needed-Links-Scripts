@echo off
:: ============================================================================
::  Visual C++ Redistributable All-in-One Installer - Launcher
:: ----------------------------------------------------------------------------
::  Created by : Kaelen & Claude (Anthropic)
::  Date       : 2026-10-04
::
::  Double-click this file. It asks for Administrator rights (needed to
::  install the runtimes), then runs Install-VCRedist.ps1 from this folder.
::  Keep both files in the same folder.
:: ============================================================================
setlocal
title Visual C++ Redistributable Installer
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"

:: ---- Already Administrator? fltmc only succeeds when elevated ----
fltmc >nul 2>&1 && goto :elevated

:: ---- Not elevated: relaunch this .bat as Administrator via UAC ----
echo Requesting Administrator privileges...
set "VCR_SELF=%~f0"
"%PS%" -NoProfile -Command "try { Start-Process -FilePath $env:VCR_SELF -Verb RunAs -ErrorAction Stop } catch { exit 1 }"
if not errorlevel 1 exit /b 0

echo.
echo Administrator privileges are required, but the UAC prompt was declined.
goto :done

:elevated
if exist "%~dp0Install-VCRedist.ps1" goto :run
echo.
echo ERROR: Install-VCRedist.ps1 was not found next to this .bat file.
echo Make sure both files are in the same folder.
goto :done

:run
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-VCRedist.ps1"

:done
echo.
echo Press any key to close...
pause >nul
endlocal
